This configuration is made for the chinese printed board
T3 or T4  with a graphical display.
Pictures and some usefull information is published from user Tomas P.
at the transistortester thread:
https://www.mikrocontroller.net/topic/248078?goto=4120737#4105488
