Attention, this Version activates another pin assignment for the LC display access.
Do not use this version for a printed board with standard port D assignments!
